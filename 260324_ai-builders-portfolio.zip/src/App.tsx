import { motion, useSpring, useScroll, useTransform, AnimatePresence } from "motion/react";
import { useState, useEffect, useRef } from "react";
import { ArrowRight, Menu, X, Github, Linkedin, Mail, ArrowUpRight, Plus } from "lucide-react";

// --- Types ---
interface Project {
  id: string;
  title: string;
  category: string;
  description: string;
  image: string;
  details: string[];
  year: string;
  color: string;
}

const PROJECTS: Project[] = [
  {
    id: "01",
    title: "Neural Canvas",
    category: "Generative Art",
    description: "A state-of-the-art AI image generation platform focused on professional editorial workflows.",
    image: "https://picsum.photos/seed/neural/1200/800",
    year: "2024",
    details: ["Stable Diffusion XL", "Custom LoRA Training", "React / Node.js"],
    color: "#FF3D00"
  },
  {
    id: "02",
    title: "Logic Flow",
    category: "AI Automation",
    description: "Visual workflow builder for complex LLM chains and multi-agent systems.",
    image: "https://picsum.photos/seed/logic/1200/800",
    year: "2024",
    details: ["LangChain", "Python Backend", "Vector Databases"],
    color: "#00E5FF"
  },
  {
    id: "03",
    title: "Synth Voice",
    category: "Audio Intelligence",
    description: "Real-time voice cloning and emotional text-to-speech engine for immersive storytelling.",
    image: "https://picsum.photos/seed/synth/1200/800",
    year: "2023",
    details: ["PyTorch", "Web Audio API", "Low Latency Streaming"],
    color: "#D500F9"
  },
  {
    id: "04",
    title: "Data Mind",
    category: "Predictive Analytics",
    description: "Enterprise-grade predictive modeling dashboard for supply chain optimization.",
    image: "https://picsum.photos/seed/data/1200/800",
    year: "2023",
    details: ["Scikit-learn", "D3.js Visualization", "BigQuery Integration"],
    color: "#00C853"
  }
];

// --- Components ---

const CustomCursor = () => {
  const [pos, setPos] = useState({ x: 0, y: 0 });
  const [isHovering, setIsHovering] = useState(false);

  useEffect(() => {
    const handleMove = (e: MouseEvent) => setPos({ x: e.clientX, y: e.clientY });
    const handleOver = (e: MouseEvent) => {
      const target = e.target as HTMLElement;
      if (target.closest('a, button, .hover-trigger')) setIsHovering(true);
      else setIsHovering(false);
    };

    window.addEventListener("mousemove", handleMove);
    window.addEventListener("mouseover", handleOver);
    return () => {
      window.removeEventListener("mousemove", handleMove);
      window.removeEventListener("mouseover", handleOver);
    };
  }, []);

  return (
    <motion.div 
      className="fixed top-0 left-0 w-6 h-6 bg-accent rounded-full pointer-events-none z-[9999] mix-blend-difference"
      animate={{ 
        x: pos.x - 12, 
        y: pos.y - 12,
        scale: isHovering ? 3 : 1,
        opacity: 1
      }}
      transition={{ type: "spring", damping: 25, stiffness: 250, mass: 0.5 }}
    />
  );
};

const Navbar = () => {
  const [isOpen, setIsOpen] = useState(false);
  const { scrollY } = useScroll();
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    return scrollY.on("change", (latest) => setIsScrolled(latest > 50));
  }, [scrollY]);

  return (
    <>
      <nav className={`fixed top-0 left-0 w-full z-[100] transition-all duration-500 px-6 py-6 flex justify-between items-center ${isScrolled ? 'bg-paper/80 backdrop-blur-md border-b border-ink/5' : ''}`}>
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 bg-ink rounded-full flex items-center justify-center">
            <div className="w-2 h-2 bg-accent rounded-full animate-pulse" />
          </div>
          <span className="font-black tracking-tighter text-xl uppercase">AI Builders</span>
        </div>
        
        <div className="hidden md:flex gap-10 text-[10px] uppercase tracking-[0.3em] font-black">
          {['Work', 'About', 'Contact'].map((item) => (
            <a key={item} href={`#${item.toLowerCase()}`} className="relative group">
              {item}
              <span className="absolute -bottom-1 left-0 w-0 h-[2px] bg-accent transition-all duration-300 group-hover:w-full" />
            </a>
          ))}
        </div>

        <button 
          onClick={() => setIsOpen(true)}
          className="w-10 h-10 flex flex-col items-center justify-center gap-1.5 group"
        >
          <div className="w-6 h-[2px] bg-ink group-hover:w-8 transition-all" />
          <div className="w-8 h-[2px] bg-ink" />
          <div className="w-4 h-[2px] bg-ink group-hover:w-8 transition-all" />
        </button>
      </nav>

      <AnimatePresence>
        {isOpen && (
          <motion.div 
            initial={{ x: "100%" }}
            animate={{ x: 0 }}
            exit={{ x: "100%" }}
            transition={{ type: "spring", damping: 30, stiffness: 200 }}
            className="fixed inset-0 bg-ink z-[200] flex flex-col p-12"
          >
            <button onClick={() => setIsOpen(false)} className="self-end text-white p-4">
              <X size={40} />
            </button>
            <div className="flex-1 flex flex-col justify-center gap-8">
              {['WORK', 'ABOUT', 'SERVICES', 'CONTACT'].map((item, i) => (
                <motion.a 
                  key={item}
                  initial={{ opacity: 0, x: 50 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: i * 0.1 + 0.3 }}
                  href={`#${item.toLowerCase()}`}
                  onClick={() => setIsOpen(false)}
                  className="text-6xl md:text-8xl font-black text-white hover:text-accent transition-colors tracking-tighter"
                >
                  {item}
                </motion.a>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
};

const Hero3D = () => {
  const containerRef = useRef<HTMLDivElement>(null);
  const [mouse, setMouse] = useState({ x: 0, y: 0 });

  useEffect(() => {
    const handleMove = (e: MouseEvent) => {
      const { innerWidth, innerHeight } = window;
      setMouse({
        x: (e.clientX / innerWidth - 0.5) * 2,
        y: (e.clientY / innerHeight - 0.5) * 2
      });
    };
    window.addEventListener("mousemove", handleMove);
    return () => window.removeEventListener("mousemove", handleMove);
  }, []);

  const springX = useSpring(mouse.x * 30, { damping: 20, stiffness: 100 });
  const springY = useSpring(mouse.y * -30, { damping: 20, stiffness: 100 });

  // 3D Extrusion layers
  const layers = Array.from({ length: 8 }).map((_, i) => i);

  return (
    <section ref={containerRef} className="relative h-screen w-full bg-paper flex items-center justify-center overflow-hidden perspective-1000">
      <div className="absolute inset-0 pointer-events-none">
        <div className="grid-line-h absolute top-1/4" />
        <div className="grid-line-h absolute top-3/4" />
        <div className="grid-line-v absolute left-1/4" />
        <div className="grid-line-v absolute left-3/4" />
      </div>

      <motion.div 
        style={{ rotateX: springY, rotateY: springX }}
        className="relative preserve-3d w-full h-full flex items-center justify-center"
      >
        {/* Extruded Text Layers */}
        {layers.map((layer) => (
          <div 
            key={layer}
            className="text-3d-layer"
            style={{ transform: `translateZ(${layer * 4}px)` }}
          >
            <h1 className={`text-[18vw] font-black leading-none tracking-tighter whitespace-nowrap ${layer === 7 ? 'text-ink' : 'text-outline opacity-10'}`}>
              AI BUILDERS
            </h1>
          </div>
        ))}

        {/* Floating Elements */}
        <motion.div 
          animate={{ y: [0, -40, 0], rotate: [0, 10, 0] }}
          transition={{ duration: 6, repeat: Infinity, ease: "easeInOut" }}
          className="absolute top-1/4 left-1/4 w-32 h-32 glass rounded-full flex items-center justify-center"
          style={{ transform: "translateZ(100px)" }}
        >
          <div className="w-4 h-4 bg-accent rounded-full shadow-[0_0_20px_var(--color-accent)]" />
        </motion.div>

        <motion.div 
          animate={{ y: [0, 50, 0], rotate: [0, -15, 0] }}
          transition={{ duration: 8, repeat: Infinity, ease: "easeInOut" }}
          className="absolute bottom-1/4 right-1/4 w-48 h-48 glass rounded-2xl"
          style={{ transform: "translateZ(150px)" }}
        />
      </motion.div>

      <div className="absolute bottom-12 left-12 flex items-center gap-6">
        <div className="flex flex-col">
          <span className="text-[10px] uppercase tracking-[0.4em] font-black opacity-30">Based in</span>
          <span className="text-sm font-black uppercase">Seoul, KR</span>
        </div>
        <div className="w-12 h-[1px] bg-ink/20" />
        <div className="flex flex-col">
          <span className="text-[10px] uppercase tracking-[0.4em] font-black opacity-30">Focus on</span>
          <span className="text-sm font-black uppercase">AI Experiences</span>
        </div>
      </div>

      <motion.div 
        animate={{ y: [0, 10, 0] }}
        transition={{ duration: 2, repeat: Infinity }}
        className="absolute bottom-12 right-12 flex flex-col items-center gap-4"
      >
        <div className="w-[1px] h-24 bg-gradient-to-b from-ink to-transparent" />
        <span className="text-[10px] uppercase tracking-[0.4em] font-black opacity-30 [writing-mode:vertical-rl]">Scroll</span>
      </motion.div>
    </section>
  );
};

interface ProjectItemProps {
  project: Project;
  index: number;
}

const ProjectItem = ({ project, index }: ProjectItemProps) => {
  const container = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({
    target: container,
    offset: ["start end", "end start"]
  });

  const y = useTransform(scrollYProgress, [0, 1], [100, -100]);
  const scale = useTransform(scrollYProgress, [0, 0.5, 1], [0.8, 1, 0.8]);

  return (
    <div ref={container} className="min-h-screen flex items-center justify-center py-24 px-6 relative">
      <div className="max-w-7xl w-full grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
        <div className="lg:col-span-5 z-10">
          <motion.div style={{ y }}>
            <span className="text-accent font-mono text-sm mb-4 block">[{project.id}]</span>
            <h3 className="text-6xl md:text-8xl font-black tracking-tighter mb-8 leading-none uppercase">
              {project.title}
            </h3>
            <p className="text-xl text-ink/60 mb-12 max-w-md leading-relaxed">
              {project.description}
            </p>
            <div className="flex flex-wrap gap-3 mb-12">
              {project.details.map(d => (
                <span key={d} className="px-4 py-2 border border-ink/10 rounded-full text-[10px] uppercase font-black tracking-widest">
                  {d}
                </span>
              ))}
            </div>
            <button className="group flex items-center gap-4">
              <span className="text-sm font-black uppercase tracking-widest border-b-2 border-accent pb-1">Case Study</span>
              <div className="w-12 h-12 rounded-full bg-ink text-white flex items-center justify-center group-hover:bg-accent transition-colors">
                <ArrowUpRight size={20} />
              </div>
            </button>
          </motion.div>
        </div>

        <div className="lg:col-span-7 relative">
          <motion.div 
            style={{ scale }}
            className="aspect-[16/10] bg-gray-100 overflow-hidden rounded-3xl shadow-2xl"
          >
            <img 
              src={project.image} 
              alt={project.title}
              className="w-full h-full object-cover grayscale hover:grayscale-0 transition-all duration-1000"
              referrerPolicy="no-referrer"
            />
          </motion.div>
          <div 
            className="absolute -top-12 -right-12 w-64 h-64 rounded-full opacity-20 blur-3xl"
            style={{ backgroundColor: project.color }}
          />
        </div>
      </div>
    </div>
  );
};

const BentoSection = () => {
  return (
    <section className="py-32 px-6 max-w-7xl mx-auto">
      <div className="grid grid-cols-1 md:grid-cols-4 md:grid-rows-2 gap-6 h-auto md:h-[800px]">
        <div className="md:col-span-2 md:row-span-2 bg-ink text-white p-12 rounded-3xl flex flex-col justify-between group overflow-hidden relative">
          <div className="relative z-10">
            <h3 className="text-4xl font-black mb-6">OUR PHILOSOPHY</h3>
            <p className="text-lg text-white/60 leading-relaxed max-w-sm">
              We believe AI is a medium, not just a tool. Our approach blends technical rigor with artistic intuition.
            </p>
          </div>
          <div className="relative z-10 flex gap-4">
            <div className="w-12 h-12 rounded-full border border-white/20 flex items-center justify-center hover:bg-white hover:text-ink transition-all">
              <Plus size={24} />
            </div>
            <span className="text-[10px] uppercase tracking-widest font-black self-center">Learn More</span>
          </div>
          <div className="absolute -bottom-20 -right-20 w-80 h-80 bg-accent rounded-full blur-[100px] opacity-20 group-hover:opacity-40 transition-opacity" />
        </div>

        <div className="md:col-span-2 bg-paper border border-ink/5 p-12 rounded-3xl flex flex-col justify-center">
          <h4 className="text-accent font-mono text-xs mb-4">01 / CAPABILITIES</h4>
          <h3 className="text-3xl font-black mb-4">GENERATIVE DESIGN</h3>
          <p className="text-sm text-ink/40">Custom AI models tailored for unique visual identities.</p>
        </div>

        <div className="bg-paper border border-ink/5 p-12 rounded-3xl flex flex-col justify-center">
          <h4 className="text-accent font-mono text-xs mb-4">02</h4>
          <h3 className="text-2xl font-black mb-2">LLM OPS</h3>
          <p className="text-xs text-ink/40">Scalable AI infrastructure.</p>
        </div>

        <div className="bg-accent text-white p-12 rounded-3xl flex flex-col justify-center group cursor-pointer">
          <ArrowUpRight size={32} className="mb-6 group-hover:translate-x-2 group-hover:-translate-y-2 transition-transform" />
          <h3 className="text-2xl font-black">START A PROJECT</h3>
        </div>
      </div>
    </section>
  );
};

const Footer = () => {
  return (
    <footer id="contact" className="bg-ink text-white py-32 px-6">
      <div className="max-w-7xl mx-auto">
        <div className="flex flex-col md:flex-row justify-between items-start gap-12 mb-32">
          <div className="max-w-xl">
            <h2 className="text-6xl md:text-9xl font-black tracking-tighter mb-12 leading-none">
              READY TO <br />
              <span className="text-outline text-white">BUILD?</span>
            </h2>
            <div className="flex gap-6">
              <button className="px-10 py-5 bg-accent text-white font-black uppercase tracking-widest rounded-full hover:scale-105 transition-transform">
                Get in touch
              </button>
              <button className="px-10 py-5 border border-white/20 text-white font-black uppercase tracking-widest rounded-full hover:bg-white hover:text-ink transition-all">
                Our Process
              </button>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-12">
            <div>
              <h4 className="text-[10px] uppercase tracking-[0.4em] font-black opacity-30 mb-8">Social</h4>
              <ul className="flex flex-col gap-4 text-sm font-black uppercase tracking-widest">
                <li><a href="#" className="hover:text-accent">Twitter</a></li>
                <li><a href="#" className="hover:text-accent">GitHub</a></li>
                <li><a href="#" className="hover:text-accent">LinkedIn</a></li>
              </ul>
            </div>
            <div>
              <h4 className="text-[10px] uppercase tracking-[0.4em] font-black opacity-30 mb-8">Contact</h4>
              <p className="text-sm font-black uppercase tracking-widest leading-loose">
                hello@aibuilders.com <br />
                +82 10 1234 5678
              </p>
            </div>
          </div>
        </div>
        <div className="flex flex-col md:flex-row justify-between items-center pt-12 border-t border-white/5 gap-8">
          <div className="flex items-center gap-3">
            <div className="w-6 h-6 bg-white rounded-full flex items-center justify-center">
              <div className="w-1.5 h-1.5 bg-accent rounded-full" />
            </div>
            <span className="font-black tracking-tighter text-sm uppercase">AI Builders © 2024</span>
          </div>
          <p className="text-[10px] uppercase tracking-[0.4em] font-black opacity-30">
            Crafted with precision in Seoul
          </p>
        </div>
      </div>
    </footer>
  );
};

export default function App() {
  return (
    <div className="antialiased selection:bg-accent selection:text-white cursor-none">
      <div className="noise" />
      <CustomCursor />
      <Navbar />
      <main>
        <Hero3D />
        <section id="work" className="bg-paper">
          {PROJECTS.map((project, i) => (
            <div key={project.id}>
              <ProjectItem project={project} index={i} />
            </div>
          ))}
        </section>
        <BentoSection />
      </main>
      <Footer />
    </div>
  );
}
